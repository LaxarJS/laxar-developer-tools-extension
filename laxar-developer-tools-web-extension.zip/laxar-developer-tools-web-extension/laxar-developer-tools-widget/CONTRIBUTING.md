# Contributing to LaxarJS

Thank you very much for your interest in becoming active in the support and the improvement of LaxarJS!

Have a look at the [contribution guidelines for LaxarJS](https://github.com/LaxarJS/laxar/blob/master/CONTRIBUTING.md) for more information.
