# AxDeveloperToolsWidget: Content

This is an embedded application, providing the content of the AxDeveloperToolsWidget.
